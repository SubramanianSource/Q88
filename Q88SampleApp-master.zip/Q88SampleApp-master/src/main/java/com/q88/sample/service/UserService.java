package com.q88.sample.service;

import java.util.List;

import com.q88.sample.model.Employee;

public interface UserService {
	
	public List<Employee> getAllUsers();

}
